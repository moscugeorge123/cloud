import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatSidenavModule,
  MatInputModule,
  MatAutocompleteModule,
  MatCard,
  MatCardModule
} from '@angular/material';


import { AppComponent } from './app.component';
import { AgmCoreModule } from '@agm/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    MatSidenavModule,
    MatInputModule,
    MatAutocompleteModule,
    HttpClientModule,
    MatCardModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBSzQMq3JPRnVGVe4xGcJx0BuR5CHAnkys'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
