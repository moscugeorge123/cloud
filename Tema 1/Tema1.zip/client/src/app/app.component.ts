import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
    title = 'app';

    pinnedLocation = '';

    weatherDetails = {};

    searchedValues: any = [];

    searchedPlace = '';

    images: any = [];

    lat = 47.16269962716132;
    lng = 27.586326599121094;

    showme(event) {
        console.log(event);
    }

    maps() {
        this.http.get(`http://localhost:3000/place?place=${this.searchedPlace}`).subscribe(value => {
            this.searchedValues = value;
        });
    }

    getWeather(event) {
        console.log(event);
        this.searchedPlace = this.pinnedLocation = event.srcElement.innerText.trim();

        const forWeather = event.srcElement.parentElement.attributes['ng-reflect-value'].value;

        this.http.get(`http://localhost:3000/weather?city=${forWeather}`).subscribe((value: any) => {
            this.weatherDetails = value;
            this.lat = value.coord.lat;
            this.lng = value.coord.lon;

        }, error => {

            console.log(error);
        });

        this.http.get(`http://localhost:3000/pictures?place=${forWeather}`).subscribe((value: any) => {
            this.images = value;

        }, error => {
            console.log(error);
        });
    }

    constructor(private http: HttpClient) { }

    ngOnInit() {
        this.pinnedLocation = 'Iasi, Romania';
        this.http.get(`http://localhost:3000/weather?city=Iasi`).subscribe((value: any) => {
            this.weatherDetails = value;
            this.lat = value.coord.lat;
            this.lng = value.coord.lon;

        }, error => {

            console.log(error);
        });

        this.http.get(`http://localhost:3000/pictures?place=Iasi`).subscribe((value: any) => {
            this.images = value;

        }, error => {
            console.log(error);
        });
    }
}
